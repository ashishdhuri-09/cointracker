package com.backend.coinTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
