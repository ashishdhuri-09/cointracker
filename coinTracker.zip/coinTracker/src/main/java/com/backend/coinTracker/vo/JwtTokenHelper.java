package com.backend.coinTracker.vo;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenHelper {

	@Value("${jwt.expirationTime}")
	private int jwtExpirationInMs;

	private static final String SECRET_KEY = "secret";

	/**
	 * Retrieves the username from the provided JWT token.
	 *
	 * @param token the JWT token from which to extract the username
	 * @return the username extracted from the token
	 */
	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	/**
	 * Retrieves the expiration date from the provided JWT token.
	 *
	 * @param token the JWT token from which to extract the expiration date
	 * @return the expiration date extracted from the token
	 */
	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	/**
	 * Retrieves a specific claim from the provided JWT token using the given claims
	 * resolver function.
	 *
	 * @param token          the JWT token from which to extract the claim
	 * @param claimsResolver the function used to resolve the desired claim from the
	 *                       token's claims
	 * @param <T>            the type of the claim to retrieve
	 * @return the specific claim extracted from the token
	 */
	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}

	/**
	 * Parses the provided JWT token, verifies its signature, and retrieves all
	 * claims from the token.
	 *
	 * @param token the JWT token to parse and retrieve claims from
	 * @return the {@link Claims} object containing all claims from the token
	 * @throws JwtException if an error occurs while parsing or verifying the token
	 */
	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
	}

	/**
	 * Generates a JWT token for the provided user details.
	 *
	 * @param userDetails the {@link UserDetails} representing the user's details
	 * @return the generated JWT token
	 */
	public String generateToken(UserDetails userDetails) {
		Map<String, Object> claims = new HashMap<>();
		return createToken(claims, userDetails.getUsername());
	}

	/**
	 * Creates a JWT token with the provided claims and subject.
	 *
	 * @param claims  the claims to include in the token
	 * @param subject the subject of the token (typically the user's identifier)
	 * @return the created JWT token
	 */
	private String createToken(Map<String, Object> claims, String subject) {
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + jwtExpirationInMs))
				.signWith(SignatureAlgorithm.HS512, SECRET_KEY).compact();
	}

	/**
	 * Validates the provided JWT token by checking if the token's username matches
	 * the username in the user details and if the token has expired.
	 *
	 * @param token       the JWT token to validate
	 * @param userDetails the {@link UserDetails} representing the user's details
	 * @return {@code true} if the token is valid, {@code false} otherwise
	 */
	public boolean validateToken(String token, UserDetails userDetails) {
		final String username = getUsernameFromToken(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}

	/**
	 * Checks if the provided JWT token has expired.
	 *
	 * @param token the JWT token to check
	 * @return {@code true} if the token has expired, {@code false} otherwise
	 */
	private boolean isTokenExpired(String token) {
		return getExpirationDateFromToken(token).before(new Date());
	}
}
