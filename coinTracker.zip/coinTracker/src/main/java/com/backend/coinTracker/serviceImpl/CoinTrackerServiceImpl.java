package com.backend.coinTracker.serviceImpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.backend.coinTracker.entity.ApiRequestResponse;
import com.backend.coinTracker.entity.Users;
import com.backend.coinTracker.exceptions.CommonException;
import com.backend.coinTracker.jwt.JwtTokenUtil;
import com.backend.coinTracker.service.ApiRequestResponseService;
import com.backend.coinTracker.service.CoinTrackerService;
import com.backend.coinTracker.service.UserService;
import com.backend.coinTracker.vo.JwtAuthResponse;
import com.backend.coinTracker.vo.LoginForm;
import com.backend.coinTracker.vo.UserUpdateVo;
import com.backend.coinTracker.vo.UsersVo;

@Service
public class CoinTrackerServiceImpl implements CoinTrackerService {

	@Autowired
	private UserService userService;

	@Autowired
	private ApiRequestResponseService apiRequestResponseService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Value("${coinmarketcap.api.key}")
	private String coinMarketCapApiKey;

	@Value("${coinmarketcap.api.url}")
	private String coinMarketCapApiUrl;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Override
	public ResponseEntity<String> userSigup(final UsersVo usersVo, final String apiKey) {
		// Validate API key
		if (!coinMarketCapApiKey.equals(apiKey)) {
			return ResponseEntity.badRequest().body("Invalid API key");
		}

		// Check if the email is already registered
		if (userService.existsByEmail(usersVo.getEmail())) {
			return ResponseEntity.badRequest().body("Email is already registered");
		}

		final Users user = new Users();
		user.setFirstName(usersVo.getFirstName());
		user.setLastName(usersVo.getLastName());
		user.setEmail(usersVo.getEmail());
		user.setUsername(usersVo.getUsername());
		user.setMobile(usersVo.getMobile());
		// Encrypt password
		final String encodedPassword = passwordEncoder.encode(usersVo.getPassword());
		user.setPassword(encodedPassword);

		// Save the user to the database
		userService.saveUser(user);

		return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
	}

	@Override
	public ResponseEntity<?> userLogin(final LoginForm loginForm, final String apiKey) {
		// Validate API key
		if (!coinMarketCapApiKey.equals(apiKey)) {
			return ResponseEntity.badRequest().body("Invalid API key");
		}

		// Check if the user exists and validate the password
		UserDetails userDetails = userService.loadUserByUsername(loginForm.getUsername());

		if (userDetails == null) {
			return ResponseEntity.badRequest().body("Invalid username");
		}

		// Check if the password matches
		if (!passwordEncoder.matches(loginForm.getPassword(), userDetails.getPassword())) {
			return ResponseEntity.badRequest().body("Invalid  password");
		}
		// Authenticate user
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginForm.getUsername(), loginForm.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		// Generate JWT token
		String token = jwtTokenUtil.generateToken(userDetails);
		System.out.println(token);
		return ResponseEntity.ok(new JwtAuthResponse(token));
	}

	@Override
	public ResponseEntity<String> getApiResponse() {
		try {
			final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			final Users user = (Users) authentication.getPrincipal();
			// Construct the request URL
			final String url = coinMarketCapApiUrl;

			// Set up the request headers
			final HttpHeaders headers = new HttpHeaders();
			headers.set("X-CMC_PRO_API_KEY", coinMarketCapApiKey);
			// Make the API request
			final RestTemplate restTemplate = new RestTemplate();
			final ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET,
					new HttpEntity<>(headers), String.class);

			final String requestBody = url; // Extract request body if needed
			final String responseBody = responseEntity.getBody();

			ApiRequestResponse apiRequestResponse = new ApiRequestResponse();
			apiRequestResponse.setUserId(user.getId());
			apiRequestResponse.setRequestBody(requestBody);
			apiRequestResponse.setResponseBody(responseBody);
			apiRequestResponse.setRequestTimestamp(LocalDateTime.now());
			apiRequestResponseService.save(apiRequestResponse);
		} catch (Exception e) {
			System.out.println("error while cointrackerresp save");
		}
		return ResponseEntity.status(HttpStatus.OK).body("coin tracker request response save successfully");
	}

	@Override
	public ResponseEntity<String> userUpdate(final UserUpdateVo userVO) {
		if (userVO != null) {
			final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			final Users user = (Users) authentication.getPrincipal();
			user.setFirstName(userVO.getFirstName());
			user.setLastName(userVO.getLastName());
			user.setMobile(userVO.getMobile());
			final String encodedPassword = passwordEncoder.encode(userVO.getPassword());
			user.setPassword(encodedPassword);

			// update the user to the database
			userService.saveUser(user);
		}
		return ResponseEntity.status(HttpStatus.CREATED).body("User updated successfully");
	}

}
