package com.backend.coinTracker.service;

import org.springframework.http.ResponseEntity;

import com.backend.coinTracker.vo.LoginForm;
import com.backend.coinTracker.vo.UserUpdateVo;
import com.backend.coinTracker.vo.UsersVo;

public interface CoinTrackerService {

	ResponseEntity<String> userSigup(final UsersVo usersVo, final String apiKey);

	ResponseEntity<?> userLogin(final LoginForm loginForm, final String apiKey);

	ResponseEntity<String> getApiResponse();

	ResponseEntity<String> userUpdate(final UserUpdateVo userVO);

}
