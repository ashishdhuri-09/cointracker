package com.backend.coinTracker.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.backend.coinTracker.validators.ValidPassword;

import lombok.Data;

@Data
public class UserUpdateVo {

	@NotBlank(message = "First name is required")
	private String firstName;

	@NotBlank(message = "Last name is required")
	private String lastName;

	@NotBlank(message = "Mobile number is required")
	@Pattern(regexp = "\\d{10}", message = "Mobile number must be 10 digits")
	private String mobile;

	@ValidPassword
	private String password;
}
