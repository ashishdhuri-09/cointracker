package com.backend.coinTracker.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "api_request_response_log")
public class ApiRequestResponse {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "request_body", length = 1000)
	private String requestBody;

	@Column(name = "response_body", columnDefinition = "LONGTEXT")
	private String responseBody;

	@Column(name = "request_timestamp")
	private LocalDateTime requestTimestamp;

}
