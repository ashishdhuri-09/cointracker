package com.backend.coinTracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.coinTracker.service.CoinTrackerService;
import com.backend.coinTracker.vo.LoginForm;
import com.backend.coinTracker.vo.UserUpdateVo;
import com.backend.coinTracker.vo.UsersVo;

@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	private CoinTrackerService coinTrackerService;

	
	@PostMapping("/signup")
	public ResponseEntity<String> signUpUser(@Validated @RequestBody UsersVo usersVo,
			@RequestHeader("X-CMC_PRO_API_KEY") String apiKey) {
		return coinTrackerService.userSigup(usersVo, apiKey);
	}

	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody LoginForm loginForm,
			@RequestHeader("X-CMC_PRO_API_KEY") String apiKey) {
		return coinTrackerService.userLogin(loginForm, apiKey);

	}

	@GetMapping("/coinTracker")
	public ResponseEntity<String> callThirdPartyApi() {
		return coinTrackerService.getApiResponse();
	}

	@PutMapping("/updateUser")
	public ResponseEntity<String> updateUser(@Validated @RequestBody UserUpdateVo userVO) {
		return coinTrackerService.userUpdate(userVO);
	}

}