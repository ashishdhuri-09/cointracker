package com.backend.coinTracker.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.client.RestTemplate;

import com.backend.coinTracker.jwt.JwtAuthenticationEntryPoint;
import com.backend.coinTracker.jwt.JwtAuthenticationFilter;
import com.backend.coinTracker.serviceImpl.UserServiceImpl;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
	private final JwtAuthenticationFilter jwtAuthenticationFilter;
	private final UserServiceImpl userServiceImpl;

	public SecurityConfig(JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint,
			JwtAuthenticationFilter jwtAuthenticationFilter, UserServiceImpl userServiceImpl) {
		this.jwtAuthenticationEntryPoint = jwtAuthenticationEntryPoint;
		this.jwtAuthenticationFilter = jwtAuthenticationFilter;
		this.userServiceImpl = userServiceImpl;
	}

//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.cors().disable().csrf().disable()
//				.authorizeRequests(authorize -> authorize.antMatchers("/api/login", "/api/signup").permitAll()
//						.anyRequest().authenticated())
//				.exceptionHandling(handling -> handling.authenticationEntryPoint(jwtAuthenticationEntryPoint))
//				.sessionManagement(management -> management.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//				.authenticationProvider(authenticationProvider())
//				.formLogin(form -> form.loginPage("/login").permitAll()).logout(logout -> logout.permitAll());
//
//		http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
//	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    http.cors().disable().csrf().disable()
	        .authorizeRequests(authorize -> authorize
	            .antMatchers("/api/login", "/api/signup").permitAll()
	            .anyRequest().authenticated())
	        .exceptionHandling(handling -> handling
	            .authenticationEntryPoint(jwtAuthenticationEntryPoint))
	        .sessionManagement(management -> management
	            .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
	        .authenticationProvider(authenticationProvider())
	        .formLogin(form -> form
	            .loginPage("/login").permitAll().disable()) // Disable form-based login
	        .logout(logout -> logout
	            .permitAll().disable()); // Disable logout
	    http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
	}

	@Bean
	DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userServiceImpl);
		authProvider.setPasswordEncoder(passwordEncoder());
		return authProvider;
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
