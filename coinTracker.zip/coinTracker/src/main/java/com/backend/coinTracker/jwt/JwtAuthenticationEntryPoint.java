package com.backend.coinTracker.jwt;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

/** Custom implementation of {@link AuthenticationEntryPoint} that handles unauthorized requests. */
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

  /**
   * Invoked when an unauthorized request is received. Sends an HTTP error response with the "401
   * Unauthorized" status and an error message.
   *
   * @param request the HTTP request that resulted in an authentication failure
   * @param response the HTTP response to send
   * @param authException the exception that caused the authentication failure
   * @throws IOException if an I/O error occurs while handling the request
   * @throws ServletException if a servlet-specific error occurs while handling the request
   */
  @Override
  public void commence(
      HttpServletRequest request,
      HttpServletResponse response,
      AuthenticationException authException)
      throws IOException, ServletException {
    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
  }
}
