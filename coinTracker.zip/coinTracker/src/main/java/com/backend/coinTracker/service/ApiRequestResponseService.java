package com.backend.coinTracker.service;

import com.backend.coinTracker.entity.ApiRequestResponse;

public interface ApiRequestResponseService {

	void save(ApiRequestResponse apiRequestResponse);

}
