package com.backend.coinTracker.jwt;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * A filter that performs JWT authentication by extracting the JWT token from
 * the request header, validating the token, and setting the authentication in
 * the security context if the token is valid.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	private JwtTokenUtil jwtTokenHelper;

	@Autowired
	private UserDetailsService userDetailsService;

	private static final Logger LOGGER = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

	/**
	 * Performs the actual filtering of the request/response by extracting the JWT
	 * token from the request header, validating the token, and setting the
	 * authentication in the security context if the token is valid.
	 *
	 * @param request     the HTTP servlet request
	 * @param response    the HTTP servlet response
	 * @param filterChain the filter chain for invoking the next filter in the chain
	 * @throws ServletException if a servlet-specific error occurs while handling
	 *                          the request
	 * @throws IOException      if an I/O error occurs while handling the request
	 */
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		// Get token from header
		String token = request.getHeader("Authorization");
		String requestUrl = request.getRequestURI();

		String username = null;

		if (StringUtils.isNotBlank(token)) {
			try {
				username = jwtTokenHelper.getUsernameFromToken(token);
			} catch (IllegalArgumentException exception) {
				LOGGER.error("unable to get jwt token");
			} catch (ExpiredJwtException exception) {
				LOGGER.error("Jwt token has been expired");
			} catch (MalformedJwtException exception) {
				LOGGER.error("Invalid Jwt token");
			}
		}

		// once we get token, now validate that token
		if (StringUtils.isNotBlank(username) && SecurityContextHolder.getContext().getAuthentication() == null) {
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);

			if (jwtTokenHelper.validateToken(token, userDetails)) {
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());

				usernamePasswordAuthenticationToken
						.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			} else {
				LOGGER.error("Invalid Jwt token");
			}
		} else {
			if (!requestUrl.equals("/api/signup")) {
				LOGGER.error("username not found");
			}

		}
		filterChain.doFilter(request, response);
	}
}
