package com.backend.coinTracker.exceptions;

import java.util.List;

import org.springframework.http.HttpStatus;

public class CommonException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private List<String> validationError;
	private final String errorMessage;
	private final HttpStatus statusCode;

	/**
	 * @return the statusCode
	 */
	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public List<String> getValidationError() {
		return validationError;
	}

	public void setValidationError(List<String> validationError) {
		this.validationError = validationError;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public CommonException(String errorMessage, HttpStatus statusCode) {
		super();
		this.validationError = null;
		this.errorMessage = errorMessage;
		this.statusCode = statusCode;
	}

	public CommonException(List<String> validationError, HttpStatus statusCode) {
		super();
		this.validationError = validationError;
		this.errorMessage = null;
		this.statusCode = statusCode;
	}
}
