package com.backend.coinTracker.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.backend.coinTracker.entity.Users;
import com.backend.coinTracker.exceptions.CommonException;
import com.backend.coinTracker.repository.UserRepository;
import com.backend.coinTracker.service.UserService;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public Users createUserProfile(Users user) {
		return userRepository.save(user);
	}

	public boolean existsByEmail(String email) {
		return userRepository.existsByEmail(email);
	}

	@Override
	public void saveUser(Users user) {
		userRepository.save(user);
	}

	@Override
	public Users findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		try {
			return userRepository.findByUsername(username);
		} catch (CommonException e) {
			e.printStackTrace();
			throw new CommonException("Username not found", HttpStatus.UNAUTHORIZED);
		}
	}

}
