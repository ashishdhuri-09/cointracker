package com.backend.coinTracker.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.backend.coinTracker.entity.Users;

public interface UserService {

	Users createUserProfile(Users user);

	boolean existsByEmail(String email);

	void saveUser(Users user);

	Users findByUsername(String currentUsername);

	UserDetails loadUserByUsername(String username) throws UsernameNotFoundException;
}
