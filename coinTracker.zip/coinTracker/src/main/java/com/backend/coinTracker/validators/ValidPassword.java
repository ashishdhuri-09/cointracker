package com.backend.coinTracker.validators;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;

@Documented
@Constraint(validatedBy = ValidPassword.PasswordValidator.class)
@Target({ ElementType.METHOD, ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidPassword {
	String message() default "Invalid password";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	class PasswordValidator implements ConstraintValidator<ValidPassword, String> {
		@Override
		public boolean isValid(String value, ConstraintValidatorContext context) {

			if (value == null || !(value instanceof String)) {
				context.disableDefaultConstraintViolation();
				context.buildConstraintViolationWithTemplate("Password is required").addConstraintViolation();
				return false;
			}

			String password = (String) value;

			// Check length
			if (password.length() < 8 || password.length() > 15) {
				setValidationError(context, "Password length must be between 8 and 15 characters");
				return false;
			}

			// Check for at least one uppercase letter
			if (!password.matches(".*[A-Z].{0,14}")) { // Max 14 any characters after uppercase
				setValidationError(context, "Password must contain at least one uppercase letter");
				return false;
			}

			// Check for at least one lowercase letter
			if (!password.matches(".*[a-z].{0,14}")) { // Max 14 any characters after lowercase
				setValidationError(context, "Password must contain at least one lowercase letter");
				return false;
			}

			// Check for at least one digit
			if (!password.matches(".*\\d.{0,14}")) { // Max 14 any characters after digit
				setValidationError(context, "Password must contain at least one digit");
				return false;
			}

			// Check for at least one special character
			if (!password.matches(".*[@#$%^&+=].{0,14}")) { // Max 14 any characters after special character
				setValidationError(context, "Password must contain at least one special character");
				return false;
			}

			return true;
		}

		private void setValidationError(ConstraintValidatorContext context, String errorMessage) {
			context.disableDefaultConstraintViolation();
			context.buildConstraintViolationWithTemplate(errorMessage).addConstraintViolation();
		}

	}
}
