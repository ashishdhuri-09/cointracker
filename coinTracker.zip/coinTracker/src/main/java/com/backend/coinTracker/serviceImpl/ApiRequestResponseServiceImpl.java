package com.backend.coinTracker.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backend.coinTracker.entity.ApiRequestResponse;
import com.backend.coinTracker.repository.ApiRequestResponseRepository;
import com.backend.coinTracker.service.ApiRequestResponseService;

@Service
public class ApiRequestResponseServiceImpl implements ApiRequestResponseService {

	
	@Autowired
	private ApiRequestResponseRepository apiRequestResponseRepository;

	@Override
	public void save(ApiRequestResponse apiRequestResponse) {
		apiRequestResponseRepository.save(apiRequestResponse);
	}
	
	

}
 